# 微信AI角色扮演聊天系统

一个功能完整的微信AI角色扮演聊天系统，支持用户注册登录、AI对话、角色设定、邀请系统和后台管理。

## 功能特性

### 🤖 微信机器人
- 基于 itchat 实现微信登录和消息收发
- 集成第三方AI API (`https://www.oiapi.net/api/BigModel`)
- 支持文本消息处理和自动回复

### 👤 用户系统
- 扫码登录微信后自动识别用户
- 注册流程：发送 `用户名/密码/邮箱`
- 登录流程：发送 `用户名/密码`
- 密码使用 bcrypt 加密存储

### 🎭 角色扮演系统
- 自定义人设（角色设定）
- 背景故事设置
- 性格选择（温柔/傲娇/高冷等）
- 性别设置
- 心声开关（AI内心独白）
- 动作描述开关
- 自定义头像上传

### 📊 邀请系统
- 生成专属邀请链接
- 邀请统计
- 邀请奖励：
  - 邀请10人 → 免费获得7天会员
  - 邀请50人 → 免费获得30天会员
- 实时显示邀请数量

### 🔧 管理后台
- 监控面板（充值统计、用户活跃度、异常检测）
- 用户管理（查看头像、封禁账号、手动添加天数）
- 管理员管理（创建账号、权限分配）

## 技术栈

| 组件 | 技术选型 |
|------|----------|
| 后端框架 | Python FastAPI |
| 微信机器人 | itchat |
| 数据库 | SQLite (开发) / MySQL (生产) |
| 缓存 | Redis |
| 前端 | 原生 HTML + CSS + JavaScript |
| 部署 | Docker + Nginx |

## 项目结构

```
微信AI角色扮演系统/
├── README.md                 # 项目说明文档
├── requirements.txt         # Python依赖
├── config.py               # 配置文件
├── docker-compose.yml      # Docker部署配置
├── database/
│   └── init.sql            # 数据库初始化SQL
├── backend/
│   ├── main.py             # 主程序入口
│   ├── wechat_bot.py       # 微信机器人模块
│   ├── user_system.py      # 用户系统
│   ├── ai_chat.py          # AI对话模块
│   ├── admin_api.py        # 管理后台API
│   ├── database.py         # 数据库操作
│   └── models.py           # 数据模型
└── frontend/
    ├── index.html          # 管理后台页面
    └── admin.js            # 前端脚本
```

## 快速开始

### 环境要求
- Python 3.8+
- Node.js 16+ (可选，用于前端)
- Docker & Docker Compose (推荐)

### 本地开发

1. **克隆项目**
```bash
cd 微信AI角色扮演系统
```

2. **安装依赖**
```bash
pip install -r requirements.txt
```

3. **配置环境**
```bash
cp config.py.example config.py
# 编辑 config.py 填写配置
```

4. **初始化数据库**
```bash
python -c "from backend.database import init_database; init_database()"
```

5. **启动后端服务**
```bash
cd backend
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

6. **启动微信机器人**
```bash
cd backend
python wechat_bot.py
```

7. **访问管理后台**
打开浏览器访问: http://localhost:8000/admin

### Docker 部署

```bash
docker-compose up -d
```

## 使用指南

### 用户命令

| 命令 | 功能 |
|------|------|
| `用户名/密码/邮箱` | 注册新账号 |
| `用户名/密码` | 登录账号 |
| `/菜单` | 显示功能菜单 |
| `/设置` | 进入角色设置 |
| `/使用时间` | 查看剩余使用时间 |
| `/对话多少句` | 查看已对话句数 |
| `/邀请用户链接生成` | 生成邀请链接 |
| `/已邀请多少人` | 查看邀请统计 |

### 角色设置选项

1. **人设** - 设定AI角色的基本设定
2. **背景故事** - 设置角色的背景故事
3. **性格** - 选择性格类型（温柔/傲娇/高冷/活泼/腹黑）
4. **性别** - 设置AI性别（男/女）
5. **心声** - 开启/关闭AI内心独白
6. **动作描述** - 开启/关闭动作描写

## 管理后台

### 访问地址
http://your-domain.com/admin

### 默认管理员
- 用户名: `EVH2`
- 密码: `liyuannb666`

### 后台功能

#### 监控面板
- 充值情况统计
- 用户消耗统计（Token/对话数）
- 异常登录检测
- 用户活跃度统计
- 充值人数统计

#### 用户管理
- 查看用户头像（检测违规内容）
- 查看邀请关系真实性
- 封禁/解封用户
- 手动添加使用天数
- 查看用户详细信息

#### 管理员管理
- 创建新管理员
- 设置管理员权限
- 删除管理员

## API 接口

### 用户接口
- `POST /api/user/register` - 用户注册
- `POST /api/user/login` - 用户登录
- `GET /api/user/info` - 获取用户信息
- `POST /api/user/settings` - 更新用户设置

### AI接口
- `POST /api/ai/chat` - 发送AI对话请求
- `POST /api/ai/settings` - 更新AI角色设置

### 管理接口
- `GET /api/admin/users` - 用户列表
- `POST /api/admin/user/ban` - 封禁用户
- `POST /api/admin/user/days` - 添加天数
- `GET /api/admin/stats` - 统计数据

### 邀请接口
- `GET /api/invite/link` - 生成邀请链接
- `GET /api/invite/stats` - 邀请统计

## 数据库表结构

### users 表
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    wechat_id VARCHAR(100),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    expire_time DATETIME,
    dialog_count INTEGER DEFAULT 0,
    invite_code VARCHAR(20) UNIQUE,
    invited_by INTEGER,
    is_banned BOOLEAN DEFAULT FALSE,
    avatar_url VARCHAR(500)
);
```

### ai_settings 表
```sql
CREATE TABLE ai_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    persona TEXT,
    background TEXT,
    personality VARCHAR(50),
    gender VARCHAR(10),
    inner_voice BOOLEAN DEFAULT FALSE,
    action_desc BOOLEAN DEFAULT TRUE,
    avatar_url VARCHAR(500),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### invitations 表
```sql
CREATE TABLE invitations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inviter_id INTEGER NOT NULL,
    invited_id INTEGER NOT NULL,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (inviter_id) REFERENCES users(id),
    FOREIGN KEY (invited_id) REFERENCES users(id)
);
```

### transactions 表
```sql
CREATE TABLE transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount DECIMAL(10, 2),
    transaction_type VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### admins 表
```sql
CREATE TABLE admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'admin',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

## 充值方案（预留）

| 套餐 | 价格 | 时长 | 功能 |
|------|------|------|------|
| 基础版 | ¥29 | 30天 | 基础对话功能 |
| 高级版 | ¥79 | 90天 | 无限对话+高级角色 |
| 永久版 | ¥199 | 永久 | 全部功能 |

> ⚠️ 支付系统待接入

## 安全说明

- 密码使用 bcrypt 加密
- 敏感信息存储在 `SECRET.md`
- 管理后台需要管理员登录
- 支持用户封禁功能

## 注意事项

1. **微信登录**: 首次使用需要扫码登录微信
2. **API配额**: 注意第三方AI API的调用限制
3. **数据备份**: 定期备份数据库
4. **违规检测**: 管理员需定期检查用户头像和内容

## License

MIT License

## 联系方式

- 官方抖音: xy07s
- 技术支持: @admin
