"""
配置文件 - 请复制此文件为 config.py 并填写实际值
敏感信息请写入 ../主对话/SECRET.md
"""

import os
from pathlib import Path

# 项目根目录
BASE_DIR = Path(__file__).parent.parent

# ==================== 数据库配置 ====================
DATABASE_URL = "sqlite:///./wechat_ai.db"
# MySQL 生产环境配置
# DATABASE_URL = "mysql+pymysql://user:password@localhost:3306/wechat_ai"

# ==================== Redis 配置 ====================
REDIS_HOST = "localhost"
REDIS_PORT = 6379
REDIS_DB = 0
REDIS_PASSWORD = None

# ==================== AI API 配置 ====================
# 请在 SECRET.md 中填写实际 API Key
AI_API_URL = "https://www.oiapi.net/api/BigModel"
AI_API_KEY = ""  # 从 SECRET.md 读取

# ==================== JWT 配置 ====================
SECRET_KEY = ""  # 从 SECRET.md 读取
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7天

# ==================== 微信机器人配置 ====================
WECHAT_QR_PATH = "./wechat_qr.png"
WECHAT_CACHE_DIR = "./wechat_cache"

# ==================== 管理后台配置 ====================
ADMIN_USERNAME = "EVH2"
ADMIN_PASSWORD = "liyuannb666"

# ==================== 邀请奖励配置 ====================
INVITE_REWARDS = {
    10: 7,   # 邀请10人 = 7天会员
    50: 30,  # 邀请50人 = 30天会员
}

# ==================== 充值配置（预留） ====================
SUBSCRIPTION_PLANS = {
    "basic": {"name": "基础版", "price": 29, "days": 30},
    "premium": {"name": "高级版", "price": 79, "days": 90},
    "permanent": {"name": "永久版", "price": 199, "days": 999999},
}

# ==================== 文件存储配置 ====================
UPLOAD_DIR = BASE_DIR / "uploads"
AVATAR_DIR = UPLOAD_DIR / "avatars"
MAX_UPLOAD_SIZE = 5 * 1024 * 1024  # 5MB

# ==================== 服务器配置 ====================
HOST = "0.0.0.0"
PORT = 8000
DEBUG = True

# ==================== CORS 配置 ====================
CORS_ORIGINS = [
    "http://localhost:8000",
    "http://127.0.0.1:8000",
]

def load_secrets():
    """从 SECRET.md 加载敏感信息"""
    secret_file = Path(__file__).parent.parent / "主对话" / "SECRET.md"
    if secret_file.exists():
        with open(secret_file, 'r', encoding='utf-8') as f:
            content = f.read()
            # 解析 SECRET.md 内容
            for line in content.split('\n'):
                if line.startswith('AI_API_KEY='):
                    global AI_API_KEY
                    AI_API_KEY = line.split('=', 1)[1].strip().strip('"').strip("'")
                elif line.startswith('SECRET_KEY='):
                    global SECRET_KEY
                    SECRET_KEY = line.split('=', 1)[1].strip().strip('"').strip("'")
                elif line.startswith('DATABASE_PASSWORD='):
                    # 可以用于 MySQL 配置
                    pass

# 初始化时加载密钥
load_secrets()
