-- 微信AI角色扮演系统 数据库初始化脚本
-- 数据库: SQLite (开发) / MySQL (生产)

-- ==================== 用户表 ====================
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    wechat_id VARCHAR(100),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    expire_time DATETIME,
    dialog_count INTEGER DEFAULT 0,
    invite_code VARCHAR(20) UNIQUE,
    invited_by INTEGER,
    is_banned BOOLEAN DEFAULT FALSE,
    avatar_url VARCHAR(500),
    total_invites INTEGER DEFAULT 0,
    last_login DATETIME,
    FOREIGN KEY (invited_by) REFERENCES users(id)
);

-- ==================== AI设置表 ====================
CREATE TABLE IF NOT EXISTS ai_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    persona TEXT DEFAULT '一个温柔体贴的AI恋人',
    background TEXT DEFAULT '我是你的专属恋人，随时陪伴在你身边',
    personality VARCHAR(50) DEFAULT '温柔',
    gender VARCHAR(10) DEFAULT '女',
    inner_voice BOOLEAN DEFAULT FALSE,
    action_desc BOOLEAN DEFAULT TRUE,
    avatar_url VARCHAR(500),
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==================== 邀请记录表 ====================
CREATE TABLE IF NOT EXISTS invitations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inviter_id INTEGER NOT NULL,
    invited_id INTEGER NOT NULL UNIQUE,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_valid BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (inviter_id) REFERENCES users(id),
    FOREIGN KEY (invited_id) REFERENCES users(id)
);

-- ==================== 交易记录表 ====================
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount DECIMAL(10, 2),
    transaction_type VARCHAR(50),
    description VARCHAR(200),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'completed',
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==================== 管理员表 ====================
CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'admin',
    permissions TEXT,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME
);

-- ==================== 操作日志表 ====================
CREATE TABLE IF NOT EXISTS admin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER,
    action VARCHAR(100),
    target_type VARCHAR(50),
    target_id INTEGER,
    details TEXT,
    ip_address VARCHAR(50),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(id)
);

-- ==================== 对话记录表 ====================
CREATE TABLE IF NOT EXISTS chat_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    message TEXT,
    response TEXT,
    token_used INTEGER,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==================== 公告表 ====================
CREATE TABLE IF NOT EXISTS announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(200),
    content TEXT,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- ==================== 索引 ====================
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_wechat_id ON users(wechat_id);
CREATE INDEX IF NOT EXISTS idx_users_invite_code ON users(invite_code);
CREATE INDEX IF NOT EXISTS idx_invitations_inviter ON invitations(inviter_id);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_logs_user ON chat_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_logs_time ON chat_logs(create_time);

-- ==================== 初始化管理员账号 ====================
-- 用户名: EVH2
-- 密码: liyuannb666
-- 密码使用 bcrypt 加密，以下是加密后的哈希值
-- $2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.W9XOWRf1Z2P8O2

INSERT OR IGNORE INTO admins (username, password_hash, role, permissions)
VALUES (
    'EVH2',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.W9XOWRf1Z2P8O2',
    'super_admin',
    '{"all": true}'
);

-- ==================== 初始化公告 ====================
INSERT OR IGNORE INTO announcements (title, content)
VALUES 
    ('欢迎使用AI恋人助手', '欢迎来到AI恋人助手！发送"用户名/密码/邮箱"进行注册，开启你的AI恋人之旅！'),
    ('邀请有礼', '邀请好友注册即可获得会员时长！邀请10人得7天，50人得30天！');
