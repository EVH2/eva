/**
 * 管理后台 JavaScript
 */

// API基础URL
const API_BASE = '';

// 状态管理
let state = {
    token: localStorage.getItem('admin_token'),
    admin: JSON.parse(localStorage.getItem('admin_info') || 'null'),
    currentPage: 1,
    pageSize: 20
};

// ==================== 初始化 ====================

document.addEventListener('DOMContentLoaded', () => {
    // 检查登录状态
    if (state.token && state.admin) {
        showDashboard();
        loadDashboard();
    } else {
        showLogin();
    }
    
    // 绑定表单事件
    bindEvents();
});

// ==================== 事件绑定 ====================

function bindEvents() {
    // 登录表单
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    
    // 添加天数表单
    document.getElementById('addDaysForm').addEventListener('submit', handleAddDays);
    
    // 创建管理员表单
    document.getElementById('createAdminForm').addEventListener('submit', handleCreateAdmin);
    
    // 回车搜索
    document.getElementById('userSearch').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            searchUsers();
        }
    });
}

// ==================== 登录相关 ====================

function showLogin() {
    document.getElementById('loginPage').style.display = 'flex';
    document.getElementById('dashboard').style.display = 'none';
}

function showDashboard() {
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('dashboard').style.display = 'block';
    document.getElementById('adminName').textContent = state.admin?.username || '管理员';
}

async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(`${API_BASE}/api/admin/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            state.token = data.token;
            state.admin = data.admin;
            localStorage.setItem('admin_token', data.token);
            localStorage.setItem('admin_info', JSON.stringify(data.admin));
            
            showDashboard();
            loadDashboard();
            showToast('登录成功！', 'success');
        } else {
            showToast(data.message || '登录失败', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showToast('网络错误，请稍后重试', 'error');
    }
}

function logout() {
    state.token = null;
    state.admin = null;
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_info');
    showLogin();
    showToast('已退出登录', 'success');
}

// ==================== 标签页切换 ====================

function switchTab(tabName) {
    // 更新标签状态
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // 更新内容
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`tab-${tabName}`).classList.add('active');
    
    // 加载对应数据
    switch (tabName) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'users':
            loadUsers(1);
            break;
        case 'admins':
            loadAdmins();
            break;
        case 'transactions':
            loadTransactions();
            break;
        case 'logs':
            loadLogs();
            break;
    }
}

// ==================== 监控面板 ====================

async function loadDashboard() {
    try {
        const response = await fetch(`${API_BASE}/api/admin/stats`, {
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error('Failed to load stats');
        }
        
        const stats = await response.json();
        
        document.getElementById('stat-total-users').textContent = stats.total_users || 0;
        document.getElementById('stat-active-users').textContent = stats.active_users || 0;
        document.getElementById('stat-today-users').textContent = stats.today_new_users || 0;
        document.getElementById('stat-total-dialogs').textContent = stats.total_dialogs || 0;
        document.getElementById('stat-total-invites').textContent = stats.total_invites || 0;
        document.getElementById('stat-banned-users').textContent = stats.banned_users || 0;
        document.getElementById('stat-revenue').textContent = `¥${(stats.total_revenue || 0).toFixed(2)}`;
        
    } catch (error) {
        console.error('Failed to load dashboard:', error);
        showToast('加载统计数据失败', 'error');
    }
}

// ==================== 用户管理 ====================

async function loadUsers(page = 1) {
    state.currentPage = page;
    
    const filter = document.getElementById('userFilter').value;
    const isBanned = filter === 'banned' ? true : (filter === 'active' ? false : null);
    
    try {
        let url = `${API_BASE}/api/admin/users?page=${page}&page_size=${state.pageSize}`;
        if (isBanned !== null) {
            url += `&is_banned=${isBanned}`;
        }
        
        const response = await fetch(url, {
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error('Failed to load users');
        }
        
        const data = await response.json();
        renderUsersTable(data.users);
        renderPagination(data.total, page, data.page_size);
        
    } catch (error) {
        console.error('Failed to load users:', error);
        document.getElementById('usersTable').innerHTML = 
            '<tr><td colspan="10" style="text-align: center; color: red;">加载失败</td></tr>';
    }
}

function renderUsersTable(users) {
    const tbody = document.getElementById('usersTable');
    
    if (!users || users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" style="text-align: center;">暂无数据</td></tr>';
        return;
    }
    
    tbody.innerHTML = users.map(user => `
        <tr>
            <td>${user.id}</td>
            <td><strong>${escapeHtml(user.username)}</strong></td>
            <td>${escapeHtml(user.email)}</td>
            <td>${escapeHtml(user.wechat_id || '-')}</td>
            <td>${user.dialog_count}</td>
            <td>${user.total_invites}</td>
            <td>
                <span class="badge ${user.remaining_days > 7 ? 'badge-success' : user.remaining_days > 0 ? 'badge-warning' : 'badge-danger'}">
                    ${user.remaining_days}天
                </span>
            </td>
            <td>
                ${user.is_banned 
                    ? '<span class="badge badge-danger">已封禁</span>' 
                    : '<span class="badge badge-success">正常</span>'}
            </td>
            <td>${formatDate(user.create_time)}</td>
            <td>
                <button class="btn-sm btn-sm-info" onclick="viewUser(${user.id})">详情</button>
                <button class="btn-sm ${user.is_banned ? 'btn-sm-success' : 'btn-sm-danger'}" 
                        onclick="toggleBan(${user.id}, ${!user.is_banned})">
                    ${user.is_banned ? '解封' : '封禁'}
                </button>
                <button class="btn-sm btn-sm-success" onclick="showAddDaysModal(${user.id}, '${escapeHtml(user.username)}')">
                    加时
                </button>
            </td>
        </tr>
    `).join('');
}

function renderPagination(total, currentPage, pageSize) {
    const totalPages = Math.ceil(total / pageSize);
    const pagination = document.getElementById('usersPagination');
    
    if (totalPages <= 1) {
        pagination.innerHTML = '';
        return;
    }
    
    let html = `
        <button ${currentPage <= 1 ? 'disabled' : ''} onclick="loadUsers(${currentPage - 1})">上一页</button>
    `;
    
    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
            html += `<button class="${i === currentPage ? 'active' : ''}" onclick="loadUsers(${i})">${i}</button>`;
        } else if (i === currentPage - 3 || i === currentPage + 3) {
            html += '<span style="padding: 0 10px;">...</span>';
        }
    }
    
    html += `<button ${currentPage >= totalPages ? 'disabled' : ''} onclick="loadUsers(${currentPage + 1})">下一页</button>`;
    html += `<span style="margin-left: 15px;">共 ${total} 条</span>`;
    
    pagination.innerHTML = html;
}

async function searchUsers() {
    const keyword = document.getElementById('userSearch').value.trim();
    
    if (!keyword) {
        loadUsers(1);
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/admin/users?search=${encodeURIComponent(keyword)}`, {
            headers: getAuthHeaders()
        });
        
        const data = await response.json();
        renderUsersTable(data.users);
        document.getElementById('usersPagination').innerHTML = '';
        
    } catch (error) {
        console.error('Search failed:', error);
        showToast('搜索失败', 'error');
    }
}

async function viewUser(userId) {
    try {
        const response = await fetch(`${API_BASE}/api/admin/users/${userId}`, {
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error('Failed to load user');
        }
        
        const data = await response.json();
        
        let message = `【用户详情】\n\n`;
        message += `用户名: ${data.user.username}\n`;
        message += `邮箱: ${data.user.email}\n`;
        message += `微信ID: ${data.user.wechat_id || '未绑定'}\n`;
        message += `注册时间: ${formatDate(data.user.create_time)}\n`;
        message += `剩余天数: ${data.user.remaining_days}天\n`;
        message += `对话数: ${data.user.dialog_count}\n`;
        message += `邀请数: ${data.user.total_invites}\n`;
        message += `状态: ${data.user.is_banned ? '已封禁' : '正常'}\n\n`;
        
        message += `【AI设置】\n`;
        message += `人设: ${data.ai_settings.persona || '-'}\n`;
        message += `背景: ${data.ai_settings.background || '-'}\n`;
        message += `性格: ${data.ai_settings.personality || '-'}\n`;
        message += `性别: ${data.ai_settings.gender || '-'}\n`;
        
        if (data.inviter) {
            message += `\n【邀请关系】\n`;
            message += `邀请者: ${data.inviter.username}\n`;
        }
        
        if (data.invited_users && data.invited_users.length > 0) {
            message += `被邀请: ${data.invited_users.map(u => u.username).join(', ')}`;
        }
        
        alert(message);
        
    } catch (error) {
        console.error('Failed to load user:', error);
        showToast('加载用户详情失败', 'error');
    }
}

async function toggleBan(userId, ban) {
    const action = ban ? '封禁' : '解封';
    const reason = prompt(`请输入${action}原因（可选）:`);
    
    try {
        const response = await fetch(`${API_BASE}/api/admin/users/ban`, {
            method: 'POST',
            headers: {
                ...getAuthHeaders(),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId,
                banned: ban,
                reason: reason || ''
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast(`用户已${action}`, 'success');
            loadUsers(state.currentPage);
        } else {
            showToast(data.message || `${action}失败`, 'error');
        }
        
    } catch (error) {
        console.error('Toggle ban failed:', error);
        showToast(`${action}失败`, 'error');
    }
}

// ==================== 添加天数 ====================

function showAddDaysModal(userId, username) {
    document.getElementById('addDaysUserId').value = userId;
    document.getElementById('addDaysUsername').textContent = username;
    document.getElementById('addDays').value = 7;
    document.getElementById('addDaysReason').value = '';
    document.getElementById('addDaysModal').classList.add('active');
}

async function handleAddDays(e) {
    e.preventDefault();
    
    const userId = document.getElementById('addDaysUserId').value;
    const days = parseInt(document.getElementById('addDays').value);
    const reason = document.getElementById('addDaysReason').value;
    
    try {
        const response = await fetch(`${API_BASE}/api/admin/users/add-days`, {
            method: 'POST',
            headers: {
                ...getAuthHeaders(),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ user_id: parseInt(userId), days, reason })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast(data.message, 'success');
            closeModal('addDaysModal');
            loadUsers(state.currentPage);
        } else {
            showToast(data.message || '添加失败', 'error');
        }
        
    } catch (error) {
        console.error('Add days failed:', error);
        showToast('添加失败', 'error');
    }
}

// ==================== 管理员管理 ====================

async function loadAdmins() {
    try {
        const response = await fetch(`${API_BASE}/api/admin/admins`, {
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error('Failed to load admins');
        }
        
        const admins = await response.json();
        renderAdminsTable(admins);
        
    } catch (error) {
        console.error('Failed to load admins:', error);
        document.getElementById('adminsTable').innerHTML = 
            '<tr><td colspan="5" style="text-align: center; color: red;">加载失败</td></tr>';
    }
}

function renderAdminsTable(admins) {
    const tbody = document.getElementById('adminsTable');
    
    if (!admins || admins.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align: center;">暂无数据</td></tr>';
        return;
    }
    
    tbody.innerHTML = admins.map(admin => `
        <tr>
            <td>${admin.id}</td>
            <td><strong>${escapeHtml(admin.username)}</strong></td>
            <td>
                <span class="badge ${admin.role === 'super_admin' ? 'badge-danger' : 'badge-success'}">
                    ${admin.role === 'super_admin' ? '超级管理员' : '管理员'}
                </span>
            </td>
            <td>${formatDate(admin.create_time)}</td>
            <td>${formatDate(admin.last_login) || '从未登录'}</td>
        </tr>
    `).join('');
}

function showCreateAdminModal() {
    document.getElementById('newAdminUsername').value = '';
    document.getElementById('newAdminPassword').value = '';
    document.getElementById('newAdminRole').value = 'admin';
    document.getElementById('createAdminModal').classList.add('active');
}

async function handleCreateAdmin(e) {
    e.preventDefault();
    
    const username = document.getElementById('newAdminUsername').value;
    const password = document.getElementById('newAdminPassword').value;
    const role = document.getElementById('newAdminRole').value;
    
    try {
        const response = await fetch(`${API_BASE}/api/admin/admins/create`, {
            method: 'POST',
            headers: {
                ...getAuthHeaders(),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password, role })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast(data.message, 'success');
            closeModal('createAdminModal');
            loadAdmins();
        } else {
            showToast(data.message || '创建失败', 'error');
        }
        
    } catch (error) {
        console.error('Create admin failed:', error);
        showToast('创建失败', 'error');
    }
}

// ==================== 交易记录 ====================

async function loadTransactions() {
    try {
        const response = await fetch(`${API_BASE}/api/admin/transactions`, {
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error('Failed to load transactions');
        }
        
        const transactions = await response.json();
        renderTransactionsTable(transactions);
        
    } catch (error) {
        console.error('Failed to load transactions:', error);
        document.getElementById('transactionsTable').innerHTML = 
            '<tr><td colspan="7" style="text-align: center; color: red;">加载失败</td></tr>';
    }
}

function renderTransactionsTable(transactions) {
    const tbody = document.getElementById('transactionsTable');
    
    if (!transactions || transactions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">暂无数据</td></tr>';
        return;
    }
    
    tbody.innerHTML = transactions.map(t => `
        <tr>
            <td>${t.id}</td>
            <td>${t.user_id}</td>
            <td>¥${(t.amount || 0).toFixed(2)}</td>
            <td>${getTransactionTypeName(t.type)}</td>
            <td>${escapeHtml(t.description || '-')}</td>
            <td>
                <span class="badge ${t.status === 'completed' ? 'badge-success' : 'badge-warning'}">
                    ${t.status === 'completed' ? '完成' : t.status}
                </span>
            </td>
            <td>${formatDate(t.time)}</td>
        </tr>
    `).join('');
}

// ==================== 操作日志 ====================

async function loadLogs() {
    try {
        const response = await fetch(`${API_BASE}/api/admin/recent-activities?limit=50`, {
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error('Failed to load logs');
        }
        
        const logs = await response.json();
        renderLogsTable(logs);
        
    } catch (error) {
        console.error('Failed to load logs:', error);
        document.getElementById('logsTable').innerHTML = 
            '<tr><td colspan="8" style="text-align: center; color: red;">加载失败</td></tr>';
    }
}

function renderLogsTable(logs) {
    const tbody = document.getElementById('logsTable');
    
    if (!logs || logs.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center;">暂无数据</td></tr>';
        return;
    }
    
    tbody.innerHTML = logs.map(log => `
        <tr>
            <td>${log.id}</td>
            <td>${escapeHtml(log.admin)}</td>
            <td>${getActionName(log.action)}</td>
            <td>${log.target_type}</td>
            <td>${log.target_id}</td>
            <td>${escapeHtml(log.details || '-')}</td>
            <td>${log.ip}</td>
            <td>${formatDate(log.time)}</td>
        </tr>
    `).join('');
}

// ==================== 工具函数 ====================

function getAuthHeaders() {
    return {
        'Authorization': `Bearer ${state.token}`,
        'Content-Type': 'application/json'
    };
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast show ${type}`;
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return '-';
    return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function getTransactionTypeName(type) {
    const types = {
        'recharge': '充值',
        'admin_grant': '管理员赠送',
        'invite_reward': '邀请奖励',
        'refund': '退款'
    };
    return types[type] || type;
}

function getActionName(action) {
    const actions = {
        'ban_user': '封禁用户',
        'unban_user': '解封用户',
        'add_days': '添加天数',
        'create_admin': '创建管理员',
        'delete_admin': '删除管理员',
        'update_settings': '更新设置'
    };
    return actions[action] || action;
}

// 点击模态框外部关闭
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});
