#!/usr/bin/env python3
"""
数据库初始化脚本
用于首次部署或重置数据库
"""

import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.database import init_database, get_sync_session, get_admin_by_username
from models import Admin
import user_system

def main():
    print("=" * 50)
    print("微信AI角色扮演聊天系统 - 数据库初始化")
    print("=" * 50)
    
    # 初始化数据库表
    print("\n[1/3] 创建数据库表...")
    init_database()
    print("✓ 数据库表创建完成")
    
    # 创建管理员账号
    print("\n[2/3] 创建管理员账号...")
    admin_username = "EVH2"
    admin_password = "liyuannb666"
    
    existing_admin = get_admin_by_username(admin_username)
    if existing_admin:
        print(f"✓ 管理员账号已存在: {admin_username}")
    else:
        hashed = user_system.hash_password(admin_password)
        from backend.database import create_admin
        create_admin(admin_username, hashed, "super_admin")
        print(f"✓ 管理员账号创建成功: {admin_username}")
    
    # 验证管理员
    print("\n[3/3] 验证管理员账号...")
    admin = get_admin_by_username(admin_username)
    if admin:
        print(f"✓ 管理员验证成功")
        print(f"  - 用户名: {admin.username}")
        print(f"  - 角色: {admin.role}")
        print(f"  - 创建时间: {admin.create_time}")
    else:
        print("✗ 管理员验证失败")
        return False
    
    print("\n" + "=" * 50)
    print("数据库初始化完成！")
    print("=" * 50)
    print("\n管理员登录信息:")
    print(f"  用户名: {admin_username}")
    print(f"  密码: {admin_password}")
    print("\n管理后台地址: http://localhost:8000/admin")
    print("=" * 50)
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n✗ 初始化失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
