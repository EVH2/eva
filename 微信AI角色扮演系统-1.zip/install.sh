#!/bin/bash

# 微信AI角色扮演聊天系统 安装脚本

set -e

echo "========================================"
echo "  微信AI角色扮演聊天系统安装向导"
echo "========================================"

# 获取脚本目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 检查系统
check_system() {
    echo -e "\n[1/5] 检查系统环境..."
    
    # 检查Python
    if ! command -v python3 &> /dev/null; then
        echo "错误: 需要Python 3.8或更高版本"
        echo "请访问 https://www.python.org/downloads/ 下载安装"
        exit 1
    fi
    
    PYTHON_VERSION=$(python3 -c 'import sys; print(sys.version_info[0]*10 + sys.version_info[1])')
    if [ "$PYTHON_VERSION" -lt 38 ]; then
        echo "错误: 需要Python 3.8或更高版本，当前版本不支持"
        exit 1
    fi
    
    echo "✓ Python版本检查通过"
    
    # 检查pip
    if ! command -v pip3 &> /dev/null; then
        echo "正在安装pip..."
        python3 -m ensurepip --upgrade
    fi
    
    echo "✓ pip检查通过"
}

# 创建虚拟环境
create_venv() {
    echo -e "\n[2/5] 创建虚拟环境..."
    
    if [ -d "venv" ]; then
        read -p "虚拟环境已存在，是否重新创建? (y/N): " recreate
        if [ "$recreate" = "y" ] || [ "$recreate" = "Y" ]; then
            rm -rf venv
            python3 -m venv venv
            echo "✓ 虚拟环境已重新创建"
        else
            echo "✓ 使用现有虚拟环境"
        fi
    else
        python3 -m venv venv
        echo "✓ 虚拟环境创建完成"
    fi
}

# 安装依赖
install_deps() {
    echo -e "\n[3/5] 安装Python依赖..."
    
    source venv/bin/activate
    pip install --upgrade pip
    pip install -r requirements.txt
    
    echo "✓ 依赖安装完成"
}

# 配置环境
setup_env() {
    echo -e "\n[4/5] 配置环境变量..."
    
    if [ ! -f ".env" ]; then
        cp .env.example .env
        echo "✓ 配置文件已创建: .env"
        echo ""
        echo "请编辑 .env 文件，填写以下配置:"
        echo "  • AI_API_KEY - AI API密钥"
        echo "  • SECRET_KEY - JWT密钥（建议使用随机字符串）"
        echo ""
        read -p "按Enter键继续..."
    else
        echo "✓ 配置文件已存在"
    fi
}

# 初始化数据库
setup_database() {
    echo -e "\n[5/5] 初始化数据库..."
    
    source venv/bin/activate
    
    # 创建目录
    mkdir -p uploads/avatars
    mkdir -p wechat_cache
    
    # 初始化数据库
    python3 -c "
import sys
sys.path.insert(0, '.')
from backend.database import init_database
init_database()
"
    
    echo "✓ 数据库初始化完成"
}

# 完成安装
finish() {
    echo -e "\n========================================"
    echo -e "  安装完成！"
    echo -e "========================================"
    echo ""
    echo "接下来可以:"
    echo ""
    echo "1. 启动Web服务:"
    echo "   source venv/bin/activate"
    echo "   uvicorn backend.main:app --reload"
    echo ""
    echo "2. 启动微信机器人:"
    echo "   source venv/bin/activate"
    echo "   python backend/wechat_bot.py"
    echo ""
    echo "3. 访问管理后台:"
    echo "   http://localhost:8000/admin"
    echo "   默认账号: EVH2 / liyuannb666"
    echo ""
    echo "4. 或者使用一键启动脚本:"
    echo "   chmod +x start.sh"
    echo "   ./start.sh"
    echo ""
    echo "========================================"
}

# 执行安装流程
check_system
create_venv
install_deps
setup_env
setup_database
finish
