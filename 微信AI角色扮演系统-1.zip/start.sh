#!/bin/bash

# 微信AI角色扮演聊天系统 启动脚本

echo "========================================"
echo "  微信AI角色扮演聊天系统启动中..."
echo "========================================"

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 检查Python版本
check_python() {
    if ! command -v python3 &> /dev/null; then
        echo -e "${RED}错误: 未安装Python3${NC}"
        exit 1
    fi
    
    PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:3])))')
    echo -e "${GREEN}✓${NC} Python版本: $PYTHON_VERSION"
}

# 检查依赖
check_dependencies() {
    echo -e "\n${YELLOW}检查依赖...${NC}"
    
    # 检查pip
    if ! command -v pip &> /dev/null && ! command -v pip3 &> /dev/null; then
        echo -e "${RED}错误: 未安装pip${NC}"
        exit 1
    fi
    
    # 安装依赖
    echo -e "${YELLOW}安装Python依赖...${NC}"
    pip3 install -r requirements.txt
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} 依赖安装完成"
    else
        echo -e "${RED}错误: 依赖安装失败${NC}"
        exit 1
    fi
}

# 初始化数据库
init_db() {
    echo -e "\n${YELLOW}初始化数据库...${NC}"
    
    cd "$(dirname "$0")"
    
    python3 -c "
import sys
sys.path.insert(0, '.')
from backend.database import init_database
init_database()
print('✓ 数据库初始化完成')
"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} 数据库初始化成功"
    else
        echo -e "${RED}错误: 数据库初始化失败${NC}"
        exit 1
    fi
}

# 创建目录
create_dirs() {
    echo -e "\n${YELLOW}创建目录...${NC}"
    
    mkdir -p uploads/avatars
    mkdir -p wechat_cache
    
    echo -e "${GREEN}✓${NC} 目录创建完成"
}

# 启动服务
start_server() {
    echo -e "\n${YELLOW}启动服务...${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}  服务地址:${NC}"
    echo -e "${GREEN}  • API文档: http://localhost:8000/docs${NC}"
    echo -e "${GREEN}  • 管理后台: http://localhost:8000/admin${NC}"
    echo -e "${GREEN}========================================${NC}\n"
    
    cd "$(dirname "$0")"
    uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
}

# 启动微信机器人（需要图形界面）
start_bot() {
    echo -e "\n${YELLOW}启动微信机器人...${NC}"
    echo -e "${YELLOW}注意: 微信机器人需要图形界面支持${NC}"
    
    cd "$(dirname "$0")"
    python3 backend/wechat_bot.py
}

# 主菜单
show_menu() {
    echo -e "\n${GREEN}========================================${NC}"
    echo -e "${GREEN}  微信AI角色扮演聊天系统${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo -e "  1. 启动Web服务"
    echo -e "  2. 启动微信机器人"
    echo -e "  3. 初始化数据库"
    echo -e "  4. 退出"
    echo -e "${GREEN}========================================${NC}"
    echo -n "请选择 [1-4]: "
}

# 主程序
main() {
    check_python
    
    while true; do
        show_menu
        read choice
        
        case $choice in
            1)
                check_dependencies
                create_dirs
                init_db
                start_server
                ;;
            2)
                check_dependencies
                start_bot
                ;;
            3)
                check_dependencies
                create_dirs
                init_db
                ;;
            4)
                echo -e "\n${GREEN}再见！${NC}"
                exit 0
                ;;
            *)
                echo -e "\n${RED}无效选择，请重试${NC}"
                ;;
        esac
    done
}

main "$@"
